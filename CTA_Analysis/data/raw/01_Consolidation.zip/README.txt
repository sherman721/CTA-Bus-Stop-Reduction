CTA BUS STOP COMBINATION OPTIMIZER - ROUTE 50 PROOF OF CONCEPT

FILES
- cta_stop_optimization.py: new combination-search optimization engine
- cta_stop_cleanup.py: required existing preprocessing dependency
- route50_optimized.xlsx: test output for Route 50 at 0% primary tolerance, with 0/5/10/15% sensitivity runs
- route50_optimized_removed_stops.csv: stop-level removal export for the primary 0% result

REQUIREMENTS
Python 3.10+ recommended
pandas, numpy, openpyxl

RUN
python cta_stop_optimization.py raw_data.csv --routes 50 -o route50_optimized.xlsx --tolerance 0 --sensitivity 0 5 10 15

For all routes in the input file, omit --routes 50.
For a longer search, increase --beam-width (default 12). A wider beam examines more alternative configurations and takes longer.

RULES CARRIED FORWARD
- Minimum-spacing candidate trigger: local 1/8 mile (660 ft) multiplied by 1 + tolerance.
  At 0/5/10/15%, this is 660/693/726/759 ft.
- Local maximum resulting gap: hard 1,500 ft; tolerance is NEVER applied to this cap.
- Rapid route spacing retains the existing rapid defaults (0.20 mile minimum and 1/3 mile maximum); only its minimum candidate trigger is tolerance-adjusted.
- Top 15% ridership protection, subject to the existing 10 average-riders minimum.
- Bottom 50% of route locations automatically pass the neighbor-ridership test; middle band must meet the existing lower-neighbor comparison; low-volume exception remains.
- Existing terminal, rail/station, crossing-route transfer, manual protection, directional asymmetric exception, moved-stop ID merge, weekday averaging, and interline-section minimum-one-shared-stop rules remain.
- Opposite-direction pairing now requires matching normalized STREET + CROSS_ST names as well as proximity. Nearby stops with different intersection names are left as separate solo directional stops and listed in the Pairing Review worksheet; affected stop rows receive PAIRING_MISMATCH_SOLO.
- Neighbor-ridership comparisons are direction-specific: each stop is compared only with ridership from its own direction, even when the neighboring intersection has a valid northbound/southbound pair.
- Original over-limit barrier gaps remain exempt from blocking a candidate when the candidate is adjacent to a pre-existing over-limit edge.
- Removed riders are distributed to adjacent retained stops using the existing inverse-distance weighting.

OPTIMIZATION METHOD AND LIMITATION
This engine uses beam search over alternative feasible removal sequences. It ranks configurations by:
1. Most complete locations consolidated;
2. Lowest cumulative passenger-weighted added walk;
3. Lowest total ridership removed;
4. Most total stop removals as a final tie-break.

Beam search is a bounded search heuristic, not a mathematical proof of the globally optimal network configuration. Increase --beam-width to explore more alternatives. The old cta_stop_reduction.py is not overwritten; this is a separate engine for side-by-side comparison.

ROUTE 50 TEST OBSERVATION
At 0% primary tolerance, the Foster section selects Wolcott and Paulina for removal and retains Ravenswood, rather than removing Ravenswood first. The resulting output was generated from the repository's included raw_data.csv (12 weekday picks averaged). The Remaining Gaps sheet flags pre-existing barrier gaps separately. The updated run uses strict street/cross-street pairing and directional-only neighbor ridership; its results should be compared with the earlier proof-of-concept workbook before interpreting changes.
